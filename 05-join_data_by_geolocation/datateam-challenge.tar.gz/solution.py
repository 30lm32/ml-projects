import getopt
import sys

import pandas as pd

from scipy.spatial import cKDTree

# I referred to C version kd-tree implementation in scipy via the below link.
# https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.cKDTree.html

# Its performance is better than pure python implementation, KDTree. That API also is providing concurrency.
# This data structure is being used in data mining, image processing mostly.

# I came across that data structure around 2008 in my first data mining lecture.
# I was used that data structure DBSCAN algorithm to reduce time complexity in terms of searching.
def joinByGPS(input_file, output_file, max_distance_in_degree, n_jobs):

    # This operation needs to be outside of this scope. It has to be loaded once.
    df_db = pd.read_csv("optd-sample-20161201.csv")

    # Selecting the coordinate over the dataframe
    db_lat_long = df_db[["latitude", "longitude"]]

    # A kd-tree is being created to efficient querying since our data is spatial data
    # In searching/querying, the average time complexity is O(log N)
    # In searching/querying, the worst case time complexity is O(N)
    kdtree = cKDTree(db_lat_long.values)

    # Reading input file and creating a dataframe
    df_input = pd.read_csv(input_file)

    # Selecting the coordinate over the dataframe
    input_lat_long = df_input[["geoip_latitude", "geoip_longitude"]]

    # We are applying whole data on the tree. The overall time complexity will be O(M * log N).
    # M denoted the number of rows in the input file, sample_data.csv.
    d, idx = kdtree.query(input_lat_long.values,
                          k=1,
                          eps=0,
                          p=2,  # Euclidean distance
                          distance_upper_bound=max_distance_in_degree,
                          n_jobs=n_jobs)

    # Selecting iata_code from the data, optd-sample-20161201.csv
    # Filtering the iata_code by index we collected the previous step
    # Filling empty string to get ride of unmatched fields value, NaN.
    # After those operations above, we need to rearrange its index to start from 0 to M-1.
    left = df_db["iata_code"]
    left = left.loc[idx - 1]
    left = left.fillna("")
    left = left.reset_index(drop=True)

    # Selecting uuid from the data sample_data.csv
    right = df_input['uuid']

    # Creating a new dataframe
    # new_df = pd.DataFrame({'iata_code': left, 'uuid': right})
    new_df = pd.concat([left, right], axis=1)

    # Writing result to CSV file under sample_data directory
    new_df.to_csv(output_file, sep=',', index=False)

    return new_df

def usage():
    print("solution.py -i <input file> -o <output file> -md <max distance in degree> -n <number of jobs>")
    return


def main():
    try:
        opts, args = getopt.getopt(sys.argv[1:], 'i:o:d:j:h', ['input=', 'output=', 'max_distance=', 'n_jobs=', 'help'])
    except getopt.GetoptError:
        usage()
        sys.exit(2)

    if len(opts) != 4:
        usage()
        sys.exit(3)

    input_file = ""
    output = ""
    max_distance = 0.01
    n_jobs = 1

    for opt, arg in opts:
        if opt in ('-h', '--help'):
            usage()
            sys.exit(2)
        elif opt in ('-i', '--input'):
            input_file = arg
        elif opt in ('-o', '--output'):
            output = arg
        elif opt in ('-d', '--max_distance='):
            max_distance = arg
        elif opt in ('-j', '--n_job='):
            n_jobs = arg
        else:
            usage()
            sys.exit(4)

    print("The process is going on...")
    df = joinByGPS(input_file, output, float(max_distance), int(n_jobs))
    print(df)


if __name__ == "__main__":
    main()
